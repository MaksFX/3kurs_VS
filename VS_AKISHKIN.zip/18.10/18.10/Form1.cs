﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _18._10
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 1)
            { textBox2.Text = "3"; textBox3.Text = "ЭСиКС"; textBox4.Text = "Информационные системы"; }
            else if (comboBox1.SelectedIndex == 2)
            { textBox2.Text = "2"; textBox3.Text = "СЭД"; textBox4.Text = "Банковское дело"; }
            else { textBox2.Text = "2"; textBox3.Text = "СЭД"; textBox4.Text = "Банковское дело"; };
        }
    }
}
